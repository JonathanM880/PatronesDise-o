package com.impl;

import anotaciones.Adaptador;

@Adaptador(metodo= "manejarAuto")
public class Auto {
	
	public void manejarAuto() {
		System.out.println("Manejando auto");
	}
}
