package com.impl;

import anotaciones.Adaptador;

@Adaptador(metodo = "operarGrua")
public class Grua {

	public void operarGrua() {
		System.out.println("Operando gr�a");
	}
}
