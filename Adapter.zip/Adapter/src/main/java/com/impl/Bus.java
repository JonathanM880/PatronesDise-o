package com.impl;

import com.inter.Vehiculo;

public class Bus implements Vehiculo{

	@Override
	public void conducir() {
		// TODO Auto-generated method stub
		System.out.println("conduce bus");
	}

}
