package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.adapter.Adaptable;
import com.impl.Auto;
import com.impl.Grua;
import com.inter.Vehiculo;

import anotaciones.Adaptador;

//repasar genericos
public class Main {
	public static void main(String[] args) throws Exception {

		Auto auto = new Auto();
		Grua grua = new Grua();

		Vehiculo autoAdap = new Adaptable<>(auto); // le quito la T
		Vehiculo gruaAdap = new Adaptable<>(grua);

		auto.manejarAuto();
		autoAdap.conducir();
		grua.operarGrua();
		gruaAdap.conducir();

		// que nomas se puede adaptar??
		System.out.println("Otro xd");
		List<Object> vehiculos = Arrays.asList(new Auto(), new Grua());

		vehiculos.stream().filter(x -> x.getClass().isAnnotationPresent(Adaptador.class)).map(a -> {
			try {
				return new Adaptable<>(a);
			} catch (Exception e) {
				throw new RuntimeException("F ");
			}
		}).forEach(Vehiculo::conducir); //acuerdate de esto
		

	}
}
