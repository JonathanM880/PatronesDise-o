package com.adapter;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.inter.Vehiculo;

import anotaciones.Adaptador;

public class Adaptable<T> implements Vehiculo{ //creo que deberia ser Adaptador para mas epicidad

	private final T instancia;
	private final Method metodo; //se puede inicializae en bloque inicializacion, constructor o al momento de instanciar
	
	public Adaptable(T instancia) throws Exception { //lanza todas las excepciones xdxd
		this.instancia =instancia;
		Class<?> clas = instancia.getClass();
		Adaptador anotacion = clas.getAnnotation(Adaptador.class);
		if(anotacion == null) {
			throw new IllegalAccessException("No mi rey");
		}
		String nombreMeth = anotacion.metodo();
		this.metodo = clas.getMethod(nombreMeth);
	} //esto es como el factoryImpl
	
	@Override
	public void conducir() {
		// TODO Auto-generated method stub
		try {
			metodo.invoke(instancia);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("F ");
		} 
	} 

}
