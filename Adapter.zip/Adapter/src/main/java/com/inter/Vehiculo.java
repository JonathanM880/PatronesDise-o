package com.inter;

public interface Vehiculo { //queremos que todos sean compatibles con esto

	void conducir();
	
}
