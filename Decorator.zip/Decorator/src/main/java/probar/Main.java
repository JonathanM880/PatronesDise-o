package probar;



import java.util.HashMap;
import java.util.Map;

import base.NotificacionLoader;
import fac.Factory;
import fac.FactoryImpl;
import inter.Notificacion;
import model.NotificacionBase;
import model.NotificacionPush;
import model.NotificacionSMS;

public class Main {
	public static void main(String[] args) {
		
        NotificacionLoader loader = new NotificacionLoader();
        loader.init("model");

        try {
            Notificacion base = loader.createNotificacion("base");

            Notificacion sms = loader.getNotificaciones().get("sms")
                    .getDeclaredConstructor(Notificacion.class).newInstance(base);

            Notificacion push = loader.getNotificaciones().get("push")
                    .getDeclaredConstructor(Notificacion.class).newInstance(sms);

            push.enviar("Mensaje dinámico decorado");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
