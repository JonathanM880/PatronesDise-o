package base;
import com.google.common.reflect.ClassPath;

import anotaciones.MiAnotacion;
import inter.Notificacion;
import model.NotificacionBase;

import java.util.HashMap;
import java.util.Map;

public class NotificacionLoader {

    private Map<String, Class<? extends Notificacion>> notificaciones = new HashMap<>();

    public void init(String packageName) {
        try {
            ClassPath classPath = ClassPath.from(getClass().getClassLoader());

            for (ClassPath.ClassInfo classInfo : classPath.getTopLevelClassesRecursive(packageName)) {
                Class<?> clazz = classInfo.load();

                if (clazz.isAnnotationPresent(MiAnotacion.class)) {
                    MiAnotacion anotacion = clazz.getAnnotation(MiAnotacion.class);
                    notificaciones.put(anotacion.name(), (Class<? extends Notificacion>) clazz);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Map<String, Class<? extends Notificacion>> getNotificaciones() {
        return notificaciones;
    }

    public Notificacion createNotificacion(String tipo) {
        Class<? extends Notificacion> notificacionClass = notificaciones.get(tipo);

        if (notificacionClass != null) {
            try {
                if (notificacionClass == NotificacionBase.class) {
                    return notificacionClass.getDeclaredConstructor().newInstance();
                } else {
                    Notificacion base = new NotificacionBase();
                    return notificacionClass.getDeclaredConstructor(Notificacion.class).newInstance(base);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return null;
    }

}
