package model;

import anotaciones.MiAnotacion;
import inter.Notificacion;

@MiAnotacion(name = "push")
public class NotificacionPush extends NotificacionDecorator{

	public NotificacionPush(Notificacion noti) {
		super(noti);
		
	
	}
	//propia y particular de esta clase
	private void enviarPush(String msg) {
		System.out.println("Se envia mensaje push " + msg);
		
	}
	
	@Override
	public void enviar(String msg) {
		super.enviar(msg); //lo que hace el objeto original
		enviarPush(msg); //lo que le aumenté
	}

}
