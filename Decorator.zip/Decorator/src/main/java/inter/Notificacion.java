package inter;

public interface Notificacion {

	void enviar(String msg);
}
